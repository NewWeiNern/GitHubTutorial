const _ = s=>{const qs = document.querySelectorAll(s); return qs.length > 1 ? qs : qs[0]};

const cam_vid = {
    video : _("#video"),
    options : initVideoObjectOptions("video"),
    camera_id : 0
};

initScanner(cam_vid.options);
// initAvailableCameras(
//     $("#select"),
//     function(){
//         cameraId = parseInt(getSelectedCamera($("#select")));
//     }
// );

initCamera(cam_vid.camera_id);
scanStart(data=>alert(data));
